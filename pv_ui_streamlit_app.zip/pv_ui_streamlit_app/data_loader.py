# data_loader.py
from __future__ import annotations
import os
from pathlib import Path
import pandas as pd
from typing import Dict, Optional

# 1) Where are the CSV folders?
# We try, in order:
#   - PV_DATA_BASE environment variable
#   - Streamlit secret "DATA_BASE" (optional)
#   - ../main (if app is in pv_ui_streamlit_app)
#   - ./main (same folder)
#   - current working directory (if it already contains the expected subfolders)

EXPECTED_SUBFOLDERS = ["net_metering", "pv_generation", "shading", "object"]

def _looks_like_base(p: Path) -> bool:
    return all((p / sub).exists() for sub in EXPECTED_SUBFOLDERS)

def resolve_base(st_secrets: Optional[dict] = None) -> Path:
    # Env
    env_base = os.getenv("PV_DATA_BASE", "").strip('"').strip("'")
    if env_base:
        p = Path(env_base).expanduser().resolve()
        if _looks_like_base(p):
            return p

    # Secret
    # BEFORE
# if st_secrets:
#     try:
#         sec = st_secrets.get("DATA_BASE", "")

    # AFTER
    if st_secrets is not None:
        try:
            sec = st_secrets.get("DATA_BASE", "")
            if sec:
                p = Path(sec).expanduser().resolve()
                if _looks_like_base(p):
                    return p
        except Exception:
            pass

    here = Path(__file__).resolve().parent
    candidates = [
        here.parent / "main",  # ../main
        here / "main",         # ./main
        Path.cwd(),            # working dir (if launched from repo root)
    ]
    for p in candidates:
        if _looks_like_base(p):
            return p

    # As a last resort, return parent/parent (user can override with env/secret)
    return here.parent

def build_paths(base: Path, state: str) -> Dict[str, Path]:
    return {
        "hourly_net":   base / "net_metering" / f"{state}_hourly_net.csv",
        "monthly_net":  base / "net_metering" / f"{state}_monthly_net.csv",
        "pv_generation":base / "pv_generation" / f"pv_generation_{state}.csv",
        "objects":      base / "object"        / f"{state}_object.csv",
        "shading":      base / "shading"       / f"{state}_pv_result.csv",
    }

def load_csv(path: Path) -> Optional[pd.DataFrame]:
    try:
        return pd.read_csv(path) if path.exists() else None
    except Exception:
        # If there is a read error, return None instead of crashing the app
        return None

def detect_states(base: Path) -> list[str]:
    # union across the folders so we see everything available
    states = set()
    try:
        for p in (base / "net_metering").glob("*_hourly_net.csv"):
            states.add(p.stem.replace("_hourly_net", ""))
    except Exception:
        pass
    try:
        for p in (base / "net_metering").glob("*_monthly_net.csv"):
            states.add(p.stem.replace("_monthly_net", ""))
    except Exception:
        pass
    try:
        for p in (base / "pv_generation").glob("pv_generation_*.csv"):
            states.add(p.stem.replace("pv_generation_", ""))
    except Exception:
        pass
    try:
        for p in (base / "shading").glob("*_pv_result.csv"):
            states.add(p.stem.replace("_pv_result", ""))
    except Exception:
        pass
    try:
        for p in (base / "object").glob("*_object.csv"):
            states.add(p.stem.replace("_object", ""))
    except Exception:
        pass
    return sorted(states)

def load_state(state: str, st_secrets: Optional[dict] = None):
    base = resolve_base(st_secrets)
    paths = build_paths(base, state)
    data = {
        "hourly_net":   load_csv(paths["hourly_net"]),
        "monthly_net":  load_csv(paths["monthly_net"]),
        "pv_generation":load_csv(paths["pv_generation"]),
        "objects":      load_csv(paths["objects"]),
        "shading":      load_csv(paths["shading"]),
    }
    debug = {
        "base": str(base),
        "exists": {k: str(v) + (" ✓" if v.exists() else " ✗") for k, v in paths.items()},
    }
    return data, debug

# Convenience to export in app
def get_states_and_base(st_secrets: Optional[dict] = None):
    base = resolve_base(st_secrets)
    return detect_states(base), base
