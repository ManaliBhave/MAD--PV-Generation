import streamlit as st
import pandas as pd
import numpy as np
import pydeck as pdk
import plotly.express as px
from data_loader import load_state, get_states_and_base
from kpi_utils import annualize_monthly, shading_kpis

st.set_page_config(page_title="PV + Shading + Tariff Explorer", layout="wide")

# Detect where data is and what sites are available
# ---- replace these two lines ----
# STATES, DATA_BASE = get_states_and_base(st.secrets if hasattr(st, "secrets") else None)

# ---- with this ----
# ---- Safe secrets + dataframe helpers ----
def _secrets_optional():
    """Return st.secrets if present; otherwise None (without crashing)."""
    try:
        return st.secrets  # raises if secrets.toml missing
    except Exception:
        return None

def normalize_cols(df: pd.DataFrame) -> pd.DataFrame:
    """Trim/normalize column names so downstream lookups don't fail."""
    df.columns = [str(c).strip() for c in df.columns]
    return df

def get_datetime_series(df: pd.DataFrame, candidates=("timestamp_local", "timestamp", "date", "Datetime")):
    """Return a parsed datetime Series from the first matching column, or None."""
    for c in candidates:
        if c in df.columns:
            s = pd.to_datetime(df[c], errors="coerce", utc=False)
            if s.notna().any():
                return s
    return None
# ------------------------------------------

# Discover available sites + base path
STATES, DATA_BASE = get_states_and_base(_secrets_optional())
if not STATES:
    st.error("No datasets found. Set PV_DATA_BASE env var or place this app next to your 'main' data folder.")
    st.stop()

# Sidebar controls
st.sidebar.title("Controls")
default_idx = STATES.index("texas") if "texas" in STATES else 0
state = st.sidebar.selectbox("Site / State", STATES, index=min(default_idx, len(STATES)-1))
show_map = st.sidebar.checkbox("Show Map", value=True)
show_uncertainty = st.sidebar.checkbox("Show Uncertainty Bands (if available)", value=False)

# Load data (for the chosen site)
data, debug = load_state(state, _secrets_optional())

# Normalize column names for every loaded frame
for k in ("monthly_net", "hourly_net", "pv_generation", "objects", "shading"):
    if data.get(k) is not None:
        data[k] = normalize_cols(data[k])

# Unpack for convenience
df_month = data["monthly_net"]
df_hour  = data["hourly_net"]
df_pv    = data["pv_generation"]
df_objs  = data["objects"]
df_shad  = data["shading"]

# Debug panel shows resolved paths and which files exist
with st.sidebar.expander("Data paths (debug)", expanded=False):
    st.write(f"Base: {debug['base']}")
    st.json(debug["exists"])

# KPIs
col1, col2, col3, col4, col5 = st.columns(5)
ak = annualize_monthly(df_month)
# Fallback to energy-only KPIs if monthly (cost) file missing
if (df_month is None or df_month.empty) and df_hour is not None:
    # Energy totals from hourly
    load_kwh = float(df_hour["Load_E_kWh"].sum()) if "Load_E_kWh" in df_hour else float(df_hour["Load_kW"].sum())
    pv_kwh   = float(df_hour["PV_E_kWh"].sum())   if "PV_E_kWh"   in df_hour else float(df_hour["PV_P_kW"].sum())
    export_kwh = float(df_hour.get("Export_kWh", pd.Series(dtype=float)).sum())
    self_consumed = max(pv_kwh - export_kwh, 0.0)
    ak.update({
        "annual_pv_kwh": pv_kwh,
        "annual_load_kwh": load_kwh,
        "annual_export_kwh": export_kwh,
        "self_consumption_pct": (self_consumed / pv_kwh * 100) if pv_kwh > 0 else 0.0,
        "self_sufficiency_pct": (self_consumed / load_kwh * 100) if load_kwh > 0 else 0.0,
        "savings_est": 0.0, "baseline_bill_est": 0.0, "avg_buy_rate": 0.0,
    })
sk = shading_kpis(df_shad)

col1.metric("Annual PV (kWh)", f'{ak.get("annual_pv_kwh",0):,.0f}')
col2.metric("Annual Load (kWh)", f'{ak.get("annual_load_kwh",0):,.0f}')
col3.metric("Self-consumption (%)", f'{ak.get("self_consumption_pct",0):.1f}%')
col4.metric("Savings (est)", f'${ak.get("savings_est",0):,.0f}')
col5.metric("Avg Shading Loss", (f'{sk.get("avg_shading_loss_pct",0):.1f}%' if sk.get("avg_shading_loss_pct") is not None else "—"))

st.markdown("---")

# Tabs
tab_overview, tab_map, tab_energy, tab_bill, tab_exports, tab_data = st.tabs(
    ["Overview", "Map & Shading", "Energy Profiles", "Billing", "Export/Import", "Data"]
)

with tab_overview:
    st.subheader(f"Summary for {state.title()}")
    if df_month is not None:
        # Monthly bar: PV vs Load
        m = df_month.copy()
        # OLD (fails on some CSVs)
# m["month"] = pd.to_datetime(m["timestamp_local"]).dt.strftime("%Y-%m")

        # NEW (safe)
        ts = get_datetime_series(m)
        if ts is None:
            st.warning("Could not parse a timestamp column in monthly data.")
        else:
            m["month"] = ts.dt.strftime("%Y-%m")

        fig = px.bar(m, x="month", y=["PV_E_kWh","Load_E_kWh"], barmode="group", title="Monthly Energy")
        st.plotly_chart(fig, use_container_width=True)

        # Savings waterfall (baseline -> buy -> sell -> net bill)
        rate = ak.get("avg_buy_rate",0)
        baseline = ak.get("baseline_bill_est",0)
        buy = m["Buy_$"].sum()
        sell = m["Sell_$"].sum()
        netbill = m["NetBill_$"].sum()
        wf = pd.DataFrame({
            "stage": ["Baseline (no PV)", "Energy bought", "Export credit", "Net bill"],
            "value": [baseline, -buy, -sell, netbill]
        })
        figw = px.waterfall(wf, x="stage", y="value", title="Annual Bill Breakdown (Estimated)")
        st.plotly_chart(figw, use_container_width=True)
    else:
        st.info("Monthly net metering file not found for this state.")

with tab_map:
    st.subheader("PV Site & Shading Objects")
    if not show_map:
        st.info("Enable 'Show Map' in the sidebar.")
    else:
        if df_objs is not None and not df_objs.empty:
            avg_lat = df_objs["latitude"].mean()
            avg_lon = df_objs["longitude"].mean()
            layer_points = pdk.Layer(
                "ScatterplotLayer",
                df_objs,
                get_position=["longitude","latitude"],
                get_radius=5,
                pickable=True,
            )
            tooltip = {"text": "Type: {object_type}\nHeight: {height_m}m\nShading Intensity: {shading_intensity}"}
            r = pdk.Deck(
                initial_view_state=pdk.ViewState(latitude=avg_lat, longitude=avg_lon, zoom=16, pitch=45),
                layers=[layer_points],
                tooltip=tooltip,
                map_style=None
            )
            st.pydeck_chart(r)
            st.caption("Objects are mock obstacles affecting shading. Future: draw/edit objects and recalc on the fly.")
        else:
            st.info("No object file found for this site.")

        if df_shad is not None and not df_shad.empty:
            sh = df_shad.copy()
            ts = get_datetime_series(sh)
            if ts is not None:
                sh["__ts__"] = ts
                daily = sh.groupby(sh["__ts__"].dt.date)["shading_loss"].mean().reset_index()
                daily.columns = ["date", "avg_shading_loss"]
                fig = px.line(daily, x="date", y="avg_shading_loss", title="Average Daily Shading Loss")
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Shading file has no parseable timestamp; skipping daily plot.")


with tab_energy:
    st.subheader("Energy Production & Load")
    if df_hour is not None:
        h = df_hour.copy()
        ts = get_datetime_series(h)
        if ts is None:
            st.warning("Could not parse a timestamp column in hourly data.")
        else:
            h["__ts__"] = ts
            fig = px.line(h, x="__ts__", y=[c for c in ["PV_P_kW","Load_kW"] if c in h], title="Power (kW)")
            st.plotly_chart(fig, use_container_width=True)

            # 8760 pivot (safe)
            pv = h.copy()
            pv["date"] = pv["__ts__"].dt.date
            pv["hour"] = pv["__ts__"].dt.hour
            value_col = "PV_E_kWh" if "PV_E_kWh" in pv.columns else ("PV_P_kW" if "PV_P_kW" in pv.columns else None)
            if value_col:
                heat = pv.pivot_table(index="hour", columns="date", values=value_col, aggfunc="sum")
                st.dataframe(heat)
                st.caption("Tip: swap to a heatmap chart if you prefer.")
            else:
                st.info("PV column not found for heatmap (looked for PV_E_kWh / PV_P_kW).")


with tab_bill:
    st.subheader("Billing & Savings")
    if df_month is not None:
        m = df_month.copy()
        m["month"] = pd.to_datetime(m["timestamp_local"]).dt.strftime("%Y-%m")
        cols = ["Buy_$","Sell_$","NetBill_$"]
        fig = px.bar(m, x="month", y=cols, barmode="group", title="Monthly Costs")
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(m[["month","Import_kWh","Export_kWh","Buy_$","Sell_$","NetBill_$"]])
    else:
        st.info("Monthly net file not found.")

with tab_exports:
    st.subheader("Import vs Export (Hourly)")
    if df_hour is not None:
        h = df_hour.copy()
        h["timestamp_local"] = pd.to_datetime(h["timestamp_local"])
        fig = px.area(h, x="timestamp_local", y=["Import_kWh","Export_kWh"], title="Import/Export Energy (kWh)")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Hourly net file not found.")

with tab_data:
    st.subheader("Raw Data Snapshots")
    if df_pv is not None:
        st.write("PV Generation (sample)")
        st.dataframe(df_pv.head(200))
    if df_shad is not None:
        st.write("Shading Result (sample)")
        st.dataframe(df_shad.head(200))
    if df_objs is not None:
        st.write("Objects")
        st.dataframe(df_objs)
    if df_month is not None:
        st.write("Monthly Net Metering")
        st.dataframe(df_month)
    if df_hour is not None:
        st.write("Hourly Net Metering (sample)")
        st.dataframe(df_hour.head(500))

st.sidebar.markdown("---")
st.sidebar.caption("Scenario management and tariff editor can be added next.")
